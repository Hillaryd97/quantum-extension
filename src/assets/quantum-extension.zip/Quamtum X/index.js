if(document.querySelector(".popup")){ //this makes sure the below code runs only if there's pop
    const button = document.querySelector(".button");
    const circle = document.querySelector(".circle");

    let buttonOn = false;

    button.addEventListener("click", () => {
        if(!buttonOn) {
            buttonOn = true;

            // to toggle the button
            circle.style.animation = "moveCircleRight 1s forwards";
            button.style.animation = "transformToYellow 1s forwards";
            
            //to style the current open tab. : that was why tab was declared in permission in index.js
            //this will actually make the page dark rather than the pop up
            chrome.tabs.query({active: true, currentWindow: true}).then(([tab]) => {
                chrome.scripting.executeScript({
                    target: {tabId: tab.id, allFrames: true},
                    files: ["darkOn.js"]
                })
            })
        } else {
            buttonOn = false;

            // to toggle the button
            circle.style.animation = "moveCircleLeft 1s forwards";
            button.style.animation = "transformToBlue 1s forwards";

            chrome.tabs.query({active: true, currentWindow: true}).then(([tab]) => {
                chrome.scripting.executeScript({
                    target: {tabId: tab.id, allFrames: true},
                    files: ["darkOff.js"]
                })
            })
        }
    })
}

// if(document.querySelector(".popup")){ //this makes sure the below code runs only if there's pop
//     const button = document.querySelector(".button");
//     const circle = document.querySelector(".circle");

//     let buttonOn = false;

//     let darkMode = false;

//     button.addEventListener("click", () => {
//         if(!buttonOn) {
//             buttonOn = true;

//             // to toggle the button
//             circle.style.animation = "moveCircleRight 1s forwards";
//             button.style.animation = "transformToYellow 1s forwards";
            
//             //to style the current open tab. : that was why tab was declared in permission in index.js
//             //this will actually make the page dark rather than the pop up
//             chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
//                 if(tabs.length === 0){
//                     return;
//                 }
//                 var tab = tabs[0];

//                 var key = 'darkMode_' + tab.url;
            
//                 chrome.storage.local.get(key, function(result) {
//                     var darkMode = result[key];
//                     if(darkMode === undefined || darkMode === false) {
//                         chrome.storage.local.set({key: true});
//                     }
//                     chrome.scripting.executeScript({
//                         target: {tabId: tab.id, allFrames: true},
//                         files: ["darkOn.js"]
//                     })
//                 })

//                 chrome.tabs.onUpdated.addListener(function(tabId, changeInfo, tab) {
//                     if(tabId === tab.id && changeInfo.status === 'complete') {
//                         //The tab has been refreshed

//                         //Restore
//                         chrome.storage.local.get(key, function(result) {
//                             var darkMode = result[key];

//                             if(darkMode === true) {
//                                 chrome.scripting.executeScript({
//                                     target: {tabId: tab.id, allFrames: true},
//                                     files: ["darkOn.js"]
//                                 })
//                             }
//                         })
//                     }
//                 })

//                     // chrome.webNavigation.onCommitted.addListener(function(details) {
//                     //     if(details.frameId === 0 && details.tabId === tab.id) {
//                     //         //The tab has navigated

//                     //         //Restore
//                     //         chrome.storage.local.get(key, function(result) {
//                     //             var darkMode = result[key];
//                     //             if(darkMode === true) {
//                     //                 chrome.scripting.executeScript({
//                     //                     target: {tabId: tab.id, allFrames: true},
//                     //                     files: ["darkOn.js"]
//                     //                 })
//                     //             }
//                     //         })
//                     //     }
//                     // })
                
//             })
//         } else {
//             buttonOn = false;

//             // to toggle the button
//             circle.style.animation = "moveCircleLeft 1s forwards";
//             button.style.animation = "transformToBlue 1s forwards";

//             chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
//                 if(tabs.length === 0){
//                     return;
//                 }
//                 var tab = tabs[0];

//                 var key = 'darkmode_' + tab.url;

//                 chrome.storage.local.get(key, function(result) {
//                     var darkMode = result[key];
//                     if(darkMode === undefined || darkMode === false) {
//                         chrome.storage.local.set({key: true});

//                         chrome.scripting.executeScript({
//                             target: {tabId: tab.id, allFrames: true},
//                             files: ["darkOff.js"]
//                         })
//                     }
//                 })

//                 chrome.tabs.onUpdated.addListener(function(tabId, changeInfo, tab) {
//                     if(tabId === tab.id && changeInfo.status === 'complete') {
//                         //The tab has been refreshed

//                         //Restore
//                         chrome.storage.local.get(key, function(result) {
//                             var darkMode = result[key];

//                             if(darkMode === true) {
//                                 chrome.scripting.executeScript({
//                                     target: {tabId: tab.id, allFrames: true},
//                                     files: ["darkOn.js"]
//                                 })
//                             }
//                         })
//                     }
//                 }) 

//                 // chrome.tabs.onUpdated.addListener(function(tabId, changeInfo, tab) {
//                 //     if(tabId === tab.id && changeInfo.status === 'complete') {
//                 //         //The tab has been refreshed

//                 //         //Restore
//                 //         chrome.storage.local.get(key, function(result) {
//                 //             var darkMode = result[key];

//                 //             if(darkMode === true) {
//                 //                 chrome.scripting.executeScript({
//                 //                     target: {tabId: tab.id, allFrames: true},
//                 //                     files: ["darkOff.js"]
//                 //                 })
//                 //             }
//                 //         })
//                 //     }
//                  // })    
//             })
//         }
//     })
// }